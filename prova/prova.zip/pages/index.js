import React from 'react'
import { Pagina } from '@/Components/Pagina'

const index = () => {
  return (
    <>
    <Pagina titulo = "Inicio">
        <h1>BEM VINDO</h1>
    </Pagina>
    </>
  )
}

export default index